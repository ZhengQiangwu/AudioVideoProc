var class_video_cap_manager =
[
    [ "CheckCamera", "class_video_cap_manager.html#aa2e69ebb843bf53fa900e64160c95794", null ],
    [ "CloseCamera", "class_video_cap_manager.html#a34e4772f9a2ae16a6d56fbb7d404b3a3", null ],
    [ "GetCameraWH", "class_video_cap_manager.html#a846560752e665a9368c30f134490effc", null ],
    [ "GetMatFromCamera", "class_video_cap_manager.html#a4db187866a6f7946e215c4c57d437efd", null ],
    [ "GetMatFromCamera", "class_video_cap_manager.html#af29a22ddc56ccf673bbec4b0cf934987", null ],
    [ "GetMindCapAttrWarn", "class_video_cap_manager.html#ac2122fc0fec0711d9e76da8e39215963", null ],
    [ "OpenCamera", "class_video_cap_manager.html#a5cc902277feb649459036722b89b68ca", null ],
    [ "RemoveCamera", "class_video_cap_manager.html#abc7934601ea2308054f8abc47037a997", null ],
    [ "SetMindCapAttrWarn", "class_video_cap_manager.html#a580bdefe1f18ff3a6d90babbbf958a14", null ]
];