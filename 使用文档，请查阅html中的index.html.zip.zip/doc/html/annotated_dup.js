var annotated_dup =
[
    [ "AudioVideoProcModule", "class_audio_video_proc_module.html", "class_audio_video_proc_module" ],
    [ "Log", "class_log.html", "class_log" ],
    [ "Tool", "class_tool.html", null ],
    [ "VideoCapManager", "class_video_cap_manager.html", "class_video_cap_manager" ]
];