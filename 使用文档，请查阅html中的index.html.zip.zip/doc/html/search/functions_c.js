var searchData=
[
  ['removeblackedge_0',['RemoveBlackEdge',['../class_tool.html#adffd67645bc0306792b1c8214dc2b457',1,'Tool']]],
  ['removecamera_1',['RemoveCamera',['../class_video_cap_manager.html#abc7934601ea2308054f8abc47037a997',1,'VideoCapManager']]]
];
