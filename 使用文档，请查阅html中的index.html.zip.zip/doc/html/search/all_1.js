var searchData=
[
  ['checkcamera_0',['CheckCamera',['../class_video_cap_manager.html#aa2e69ebb843bf53fa900e64160c95794',1,'VideoCapManager']]],
  ['checkcameratype_1',['CheckCameraType',['../namespace_audio_video_proc_name_space.html#ae5a02f5a7939bbc1e685529484069a98',1,'AudioVideoProcNameSpace']]],
  ['closecamera_2',['CloseCamera',['../class_video_cap_manager.html#a34e4772f9a2ae16a6d56fbb7d404b3a3',1,'VideoCapManager']]],
  ['continuerecord_3',['ContinueRecord',['../class_audio_video_proc_module.html#aa7b629e482bd4bf39a682629e7d1d820',1,'AudioVideoProcModule::ContinueRecord()'],['../namespace_audio_video_proc_name_space.html#a302de284049ff0c099539dfe1d4ec790',1,'AudioVideoProcNameSpace::ContinueRecord()']]]
];
