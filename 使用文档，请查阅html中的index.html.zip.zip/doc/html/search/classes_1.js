var searchData=
[
  ['log_0',['Log',['../class_log.html',1,'']]]
];
