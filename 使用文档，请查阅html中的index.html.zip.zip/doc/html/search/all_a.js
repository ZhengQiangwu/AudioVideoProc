var searchData=
[
  ['opencamera_0',['OpenCamera',['../class_video_cap_manager.html#a5cc902277feb649459036722b89b68ca',1,'VideoCapManager']]]
];
