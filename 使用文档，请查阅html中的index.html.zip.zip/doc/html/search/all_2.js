var searchData=
[
  ['debug_0',['Debug',['../class_log.html#a05b71f0a65840fcd7f86c40fc1ddee7a',1,'Log::Debug(const char *Message)'],['../class_log.html#a5a588008cd9726c2d7e5765ecdf93e48',1,'Log::Debug(const std::string &amp;Message)']]],
  ['default_1',['Default',['../class_log.html#ad3d3dd4fbd88a6423400bcda17044672',1,'Log']]]
];
