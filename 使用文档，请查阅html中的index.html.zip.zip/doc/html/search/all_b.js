var searchData=
[
  ['pauserecord_0',['PauseRecord',['../class_audio_video_proc_module.html#aa78de0d686bd5c4953541ebcd7e3e9be',1,'AudioVideoProcModule::PauseRecord()'],['../namespace_audio_video_proc_name_space.html#a7c6b65b58dbd7294efc9a4b8cade7c82',1,'AudioVideoProcNameSpace::PauseRecord()']]]
];
