var searchData=
[
  ['recordtype_0',['RecordType',['../class_audio_video_proc_module.html#a2af18a7d48170cf395945d690bdbdd2c',1,'AudioVideoProcModule']]],
  ['removeblackedge_1',['RemoveBlackEdge',['../class_tool.html#adffd67645bc0306792b1c8214dc2b457',1,'Tool']]],
  ['removecamera_2',['RemoveCamera',['../class_video_cap_manager.html#abc7934601ea2308054f8abc47037a997',1,'VideoCapManager']]]
];
