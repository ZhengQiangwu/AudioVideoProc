var indexSectionsWithContent =
{
  0: "acdefghilmoprstuvw~",
  1: "altv",
  2: "a",
  3: "acdefghilmoprsuw~",
  4: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "函数",
  4: "枚举"
};

