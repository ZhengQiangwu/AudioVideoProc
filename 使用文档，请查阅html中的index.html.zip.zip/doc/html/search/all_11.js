var searchData=
[
  ['warn_0',['Warn',['../class_log.html#a5551b2fa91f88a78f32409dbc9664b2f',1,'Log::Warn(const char *Message)'],['../class_log.html#a32452c86976b5a9967a74d290f3acaf6',1,'Log::Warn(const std::string &amp;Message)']]]
];
