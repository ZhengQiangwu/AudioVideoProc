var searchData=
[
  ['log_0',['Log',['../class_log.html',1,'Log'],['../class_log.html#af6071a60aa52b6c1b511f99b4bc1b8fe',1,'Log::Log()']]]
];
