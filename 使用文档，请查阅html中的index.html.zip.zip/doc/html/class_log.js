var class_log =
[
    [ "Log", "class_log.html#af6071a60aa52b6c1b511f99b4bc1b8fe", null ],
    [ "~Log", "class_log.html#a0fbfda88fbee5027c89f6eb121059360", null ],
    [ "Debug", "class_log.html#a05b71f0a65840fcd7f86c40fc1ddee7a", null ],
    [ "Debug", "class_log.html#a5a588008cd9726c2d7e5765ecdf93e48", null ],
    [ "Error", "class_log.html#ab1c16bd5f6e9b38372d7814b47d5e544", null ],
    [ "Error", "class_log.html#ae5df3b735161fbcca9cf649cdaaa9d84", null ],
    [ "Info", "class_log.html#a7171f6c7f9b88e0a028a5cf9383831db", null ],
    [ "Info", "class_log.html#a8a0d99b1d75dfb7cfb0cb737080349a5", null ],
    [ "SetCallBack", "class_log.html#aa87811f4d6b6ff12e5195c45495bd3d3", null ],
    [ "Warn", "class_log.html#a5551b2fa91f88a78f32409dbc9664b2f", null ],
    [ "Warn", "class_log.html#a32452c86976b5a9967a74d290f3acaf6", null ]
];